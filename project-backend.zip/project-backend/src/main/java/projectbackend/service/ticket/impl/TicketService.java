package projectbackend.service.ticket.impl;

import org.springframework.stereotype.Service;
import projectbackend.service.ticket.ITicketService;

@Service
public class TicketService implements ITicketService {
}
