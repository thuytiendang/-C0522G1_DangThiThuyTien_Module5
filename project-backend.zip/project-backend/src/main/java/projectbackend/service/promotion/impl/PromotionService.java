package projectbackend.service.promotion.impl;

import org.springframework.stereotype.Service;
import projectbackend.service.promotion.IPromotionService;

@Service
public class PromotionService implements IPromotionService {
}
