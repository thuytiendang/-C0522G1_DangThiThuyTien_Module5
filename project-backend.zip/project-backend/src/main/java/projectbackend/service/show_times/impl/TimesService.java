package projectbackend.service.show_times.impl;

import org.springframework.stereotype.Service;
import projectbackend.service.show_times.ITimesService;

@Service
public class TimesService implements ITimesService {
}
