package projectbackend.service.movie;

public interface ICommentMovieService {
}
