package projectbackend.service.movie;

public interface IMovieTypeService {
}
