package projectbackend.service.movie.impl;

import org.springframework.stereotype.Service;
import projectbackend.service.movie.ICommentMovieService;

@Service
public class CommentMovieService implements ICommentMovieService {
}
