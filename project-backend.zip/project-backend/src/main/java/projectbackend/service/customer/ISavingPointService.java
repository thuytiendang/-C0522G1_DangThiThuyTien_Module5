package projectbackend.service.customer;

public interface ISavingPointService {
}
