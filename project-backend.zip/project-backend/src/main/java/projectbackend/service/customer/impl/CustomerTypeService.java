package projectbackend.service.customer.impl;

import org.springframework.stereotype.Service;
import projectbackend.service.customer.ICustomerTypeService;

@Service
public class CustomerTypeService implements ICustomerTypeService {
}
