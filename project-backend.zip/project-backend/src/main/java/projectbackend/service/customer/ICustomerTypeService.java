package projectbackend.service.customer;

public interface ICustomerTypeService {
}
