package projectbackend.service.customer.impl;

import org.springframework.stereotype.Service;
import projectbackend.service.customer.ICustomerService;

@Service
public class CustomerService implements ICustomerService {
}
