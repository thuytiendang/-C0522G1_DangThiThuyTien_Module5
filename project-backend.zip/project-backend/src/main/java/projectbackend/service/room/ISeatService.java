package projectbackend.service.room;

public interface ISeatService {
}
