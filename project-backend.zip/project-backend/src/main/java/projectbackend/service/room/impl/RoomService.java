package projectbackend.service.room.impl;

import org.springframework.stereotype.Service;
import projectbackend.service.room.IRoomService;

@Service
public class RoomService implements IRoomService {
}
