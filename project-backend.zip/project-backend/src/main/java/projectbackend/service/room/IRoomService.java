package projectbackend.service.room;

public interface IRoomService {
}
