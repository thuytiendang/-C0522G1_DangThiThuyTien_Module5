package projectbackend.service.room;

public interface ISeatTypeService {
}
