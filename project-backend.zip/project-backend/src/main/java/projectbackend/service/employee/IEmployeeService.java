package projectbackend.service.employee;

public interface IEmployeeService {
}
