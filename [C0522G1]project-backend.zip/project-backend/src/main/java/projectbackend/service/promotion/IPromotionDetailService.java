package projectbackend.service.promotion;

public interface IPromotionDetailService {
}
