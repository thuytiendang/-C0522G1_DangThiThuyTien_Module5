package projectbackend.service.promotion.impl;

import org.springframework.stereotype.Service;
import projectbackend.service.promotion.IPromotionDetailService;

@Service
public class PromotionDetailService implements IPromotionDetailService {
}
