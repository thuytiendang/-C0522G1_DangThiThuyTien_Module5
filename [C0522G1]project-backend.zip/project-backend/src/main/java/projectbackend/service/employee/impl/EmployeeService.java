package projectbackend.service.employee.impl;

import org.springframework.stereotype.Service;
import projectbackend.service.employee.IEmployeeService;

@Service
public class EmployeeService implements IEmployeeService {
}
