package projectbackend.service.show_times.impl;

import org.springframework.stereotype.Service;
import projectbackend.service.show_times.IShowTimesService;

@Service
public class ShowTimesService implements IShowTimesService {
}
