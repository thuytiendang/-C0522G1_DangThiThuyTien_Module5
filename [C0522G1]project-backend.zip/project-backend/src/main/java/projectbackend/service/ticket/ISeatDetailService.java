package projectbackend.service.ticket;

public interface ISeatDetailService {
}
