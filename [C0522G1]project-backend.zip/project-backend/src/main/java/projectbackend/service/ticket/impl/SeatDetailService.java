package projectbackend.service.ticket.impl;

import org.springframework.stereotype.Service;
import projectbackend.service.ticket.ISeatDetailService;

@Service
public class SeatDetailService implements ISeatDetailService {
}
