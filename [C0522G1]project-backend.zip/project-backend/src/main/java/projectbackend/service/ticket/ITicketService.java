package projectbackend.service.ticket;

public interface ITicketService {
}
