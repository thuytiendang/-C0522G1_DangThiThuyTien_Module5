package projectbackend.service.decentralization.impl;

import org.springframework.stereotype.Service;
import projectbackend.service.decentralization.IRoleService;

@Service
public class RoleService implements IRoleService {
}
