package projectbackend.service.decentralization;

public interface IUserService {
}
