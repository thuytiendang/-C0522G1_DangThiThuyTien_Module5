package projectbackend.service.decentralization.impl;

import org.springframework.stereotype.Service;
import projectbackend.service.decentralization.IUserService;

@Service
public class UserService implements IUserService {
}
