package projectbackend.service.room.impl;

import org.springframework.stereotype.Service;
import projectbackend.service.room.ISeatRoomService;

@Service
public class SeatRoomService implements ISeatRoomService {
}
