package projectbackend.service.room;

public interface ISeatRoomService {
}
