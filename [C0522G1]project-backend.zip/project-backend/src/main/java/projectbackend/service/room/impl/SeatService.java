package projectbackend.service.room.impl;

import org.springframework.stereotype.Service;
import projectbackend.service.room.ISeatService;

@Service
public class SeatService implements ISeatService {
}
