package projectbackend.service.movie.impl;

import org.springframework.stereotype.Service;
import projectbackend.service.movie.IMovieService;

@Service
public class MovieService implements IMovieService {
}
