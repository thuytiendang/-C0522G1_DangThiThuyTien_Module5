package projectbackend.service.movie.impl;

import org.springframework.stereotype.Service;
import projectbackend.service.movie.IMovieTypeService;

@Service
public class MovieTypeService implements IMovieTypeService {
}
