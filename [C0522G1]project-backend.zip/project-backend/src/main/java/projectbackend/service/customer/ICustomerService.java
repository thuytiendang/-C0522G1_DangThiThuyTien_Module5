package projectbackend.service.customer;

public interface ICustomerService {
}
