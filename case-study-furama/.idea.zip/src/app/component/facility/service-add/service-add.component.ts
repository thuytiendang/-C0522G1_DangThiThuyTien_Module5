import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-service-add',
  templateUrl: './service-add.component.html',
  styleUrls: ['./service-add.component.css']
})
export class ServiceAddComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
