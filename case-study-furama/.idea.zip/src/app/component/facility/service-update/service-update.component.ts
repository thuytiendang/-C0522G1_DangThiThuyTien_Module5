import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-service-update',
  templateUrl: './service-update.component.html',
  styleUrls: ['./service-update.component.css']
})
export class ServiceUpdateComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
