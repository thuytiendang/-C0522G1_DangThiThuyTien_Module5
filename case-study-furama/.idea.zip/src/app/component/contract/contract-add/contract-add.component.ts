import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-contract-add',
  templateUrl: './contract-add.component.html',
  styleUrls: ['./contract-add.component.css']
})
export class ContractAddComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
