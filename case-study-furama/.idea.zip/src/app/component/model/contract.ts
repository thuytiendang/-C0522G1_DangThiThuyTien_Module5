export interface Contract {
  contractCode?: number;
  startDate?: string;
  endDate?: string;
  deposit?: number;
  total?: string;
}
