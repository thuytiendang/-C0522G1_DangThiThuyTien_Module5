export interface TypeCustomer {
    id? : number;
    name? : string;
}
